#!/bin/sh

pushd `dirname $0` > /dev/null
SCRIPTPATH=`pwd -P`
popd > /dev/null
BEDPOSTDIR=$SCRIPTPATH/bedpost

time bedpostx_gpu $BEDPOSTDIR