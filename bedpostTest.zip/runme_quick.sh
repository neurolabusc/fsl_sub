#!/bin/sh

pushd `dirname $0` > /dev/null
SCRIPTPATH=`pwd -P`
popd > /dev/null
BEDPOSTDIR=$SCRIPTPATH/bedpost

echo "fsl_sub running $COMMANDNAME with parallel processing disabled"
FSLPARALLEL=0
time bedpostx $BEDPOSTDIR

echo "fsl_sub running $COMMANDNAME with parallel processing enabled"
FSLPARALLEL=1
time bedpostx $BEDPOSTDIR



